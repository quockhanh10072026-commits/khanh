LEONARDO DA VINCI — WEBSITE TIN HỌC 12
Lớp: 12A11
Thành viên: Phạm Nhật Đăng và Huỳnh Thị Bảo Thuy

CÁCH MỞ WEBSITE OFFLINE
1. Giải nén toàn bộ thư mục website.
2. Giữ nguyên các thư mục images và media cùng các tệp HTML, CSS, JavaScript.
3. Mở index.html bằng Chrome hoặc trình duyệt khác.
4. Dùng nút menu ba gạch ở góc trên bên phải để chuyển giữa 8 trang.

TÀI NGUYÊN
- Hình minh họa vector nằm trong images/ và được lưu cục bộ.
- Nội dung nhúng tóm tắt nằm trong media/story.svg và hoạt động offline.
- Các liên kết nguồn và video trực tuyến chỉ hoạt động khi có Internet.
- Kiểm tra lại nội dung, nguồn và hình ảnh trước khi nộp bài.

CẤU TRÚC NỘP BÀI
Nén toàn bộ thư mục website thành ZIP. Đặt tên tệp theo đúng cấu trúc giáo viên yêu cầu và số nhóm thực tế của lớp.
