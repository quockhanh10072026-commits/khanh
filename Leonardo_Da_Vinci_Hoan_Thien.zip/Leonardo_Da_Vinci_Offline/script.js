document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".menu-toggle").forEach(function (button) {
    const nav = button.parentElement.querySelector("nav");
    if (!nav) return;
    button.addEventListener("click", function () {
      const opened = button.getAttribute("aria-expanded") === "true";
      button.setAttribute("aria-expanded", String(!opened));
      nav.classList.toggle("is-open", !opened);
    });
    nav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        nav.classList.remove("is-open");
        button.setAttribute("aria-expanded", "false");
      });
    });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        nav.classList.remove("is-open");
        button.setAttribute("aria-expanded", "false");
      }
    });
  });
});